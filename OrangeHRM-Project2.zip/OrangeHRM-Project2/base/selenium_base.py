from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as ec
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.support.select import Select
from utilities.utils import *

class SeleniumBase:
    def __init__(self, driver, timeout=30):
        self.driver = driver
        self.timeout = timeout
        self.wait = WebDriverWait(self.driver, timeout=self.timeout)


    def get_element(self, locator):
        try:
            element = self.wait.until(ec.visibility_of_element_located(locator))
            return element
        except Exception as e:
            filename = get_unique_name()
            self.driver.save_screenshot(f"/logs/{filename}.png")
            raise

    def clear_input(self, locator):
        element = self.get_element(locator)
        element.clear()

    def click_element(self, locator):
        element = self.get_element(locator)
        if element:
            element.click()
        else:
            print(f"Element no found, {locator}")

    def enter_values(self, locator, data):
        element = self.get_element(locator)
        if element:
            element.send_keys(data)
        else:
            print(f"Element no found, {locator}")

    def get_text(self, locator):
        try:
            element = self.get_element(locator)
            return element.text
        except Exception as e:
            filename = get_unique_name()
            self.driver.save_screenshot(f"/logs/{filename}.png")
            raise

    def get_elements(self, locator):
        try:
            elements = self.wait.until(ec.visibility_of_all_elements_located(locator))
            return elements
        except Exception as e:
            print(f"Element not found, {locator}")

    def windows_handle(self):
        window_list = self.driver.window_handles
        print("window_list: ", window_list)
        return self.driver.switch_to.window([1])

    def switch_to_default_windows(self):
        window_list = self.driver.window_handles
        self.driver.close()
        return self.driver.switch_to.window(window_list[0])