import pytest
from data.orangeHRM_data import *
from modules.login.login import Login


@pytest.mark.usefixtures("initiate_driver")
class TestAdmin:

    @pytest.fixture(autouse=True)
    def setup(self):
        self.lg = Login(self.driver)

    def test_forgot_password(self):
        self.lg.forgot_password(
            username=orangehrm_test_data['login']['username'],
        )

