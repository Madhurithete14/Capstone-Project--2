import pytest
from data.orangeHRM_data import *
from modules.login.login import Login


@pytest.mark.usefixtures("initiate_driver")
class TestLogin:

    @pytest.fixture(autouse=True)
    def setup(self):
        self.lg = Login(self.driver)

    def test_login_success(self):
        self.lg.login_success(
            username=orangehrm_test_data['login']['username'],
            password=orangehrm_test_data['login']['password']
        )

    def test_validate_admin_page(self):
        self.lg.validate_admin_page()

    def test_validate_admin_main_menu(self):
        self.lg.validate_admin_main_menu()

