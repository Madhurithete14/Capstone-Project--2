from selenium.webdriver.common.by import By
# Login
username_locator = (By.NAME, "username")
password_locator = (By.NAME, "password")
submit_login_locator = (By.XPATH, "//button[@type='submit']")
invalid_login_err_locator = (By.XPATH, "//p[text()='Invalid credentials']")
pim_link_locator = (By.XPATH, "//a[@href='/web/index.php/pim/viewPimModule']")
# Add
add_new_employee_locator = (By.XPATH, "//div[@class='orangehrm-header-container']//button")
firstname_input_locator = (By.NAME, "firstName")
middlename_input_locator = (By.NAME, "middleName")
lastname_input_locator = (By.NAME, "lastName")
add_employee_locator = (By.XPATH, "//button[@type='submit']")
# Update
employee_list_locator = (By.XPATH,"//a[contains(text(), 'Employee List')]")
edit_employee_locator = (By.XPATH,"(//div[@class='oxd-table-body']//i[@class='oxd-icon bi-pencil-fill'])[2]")
# edit_firstname_locator = (By.NAME, "firstName")
# edit_middlename_locator = (By.NAME, "middleName")
# edit_lastname_locator = (By.NAME, "lastName")
update_emp_personal_details_locator = (By.XPATH, "(//button[@type='submit'])[1]")
delete_employee_locator = (By.XPATH, "(//div[@class='oxd-table-body']//i[@class='oxd-icon bi-trash'])[1]")
delete_confirm_btn_locator = (By.XPATH, "//i[@class='oxd-icon bi-trash oxd-button-icon']//parent::button")
forgot_password_locator = (By.XPATH, "//div[@class='orangehrm-login-forgot']//p")
# Admin Page
admin_link_locator = (By.XPATH, "//a[@href='/web/index.php/admin/viewAdminModule']")
admin_navbar_locator = (By.XPATH, "//span[@class='oxd-topbar-body-nav-tab-item']")
user_mgnt_locator = (By.XPATH, "//span[normalize-space()='User Management']")
job_locator = (By.XPATH, "//span[normalize-space()='Job']")
organization_locator = (By.XPATH, "//span[normalize-space()='Organization']")
qualification_locator = (By.XPATH, "//span[normalize-space()='Qualifications']")
more_locator = (By.XPATH, "//span[normalize-space()='More']")
# Admin Menu
leave_link_locator = (By.XPATH, "//a[@href='/web/index.php/leave/viewLeaveModule']")
time_link_locator = (By.XPATH, "//a[@href='/web/index.php/time/viewTimeModule']")
recruitment_link_locator = (By.XPATH, "//a[@href='/web/index.php/recruitment/viewRecruitmentModule']")
myinfo_link_locator = (By.XPATH, "//a[@href='/web/index.php/pim/viewMyDetails']")
performance_link_locator = (By.XPATH, "//a[@href='/web/index.php/performance/viewPerformanceModule']")
dashboard_link_locator = (By.XPATH, "//a[@href='/web/index.php/dashboard/index']")
directory_link_locator = (By.XPATH, "//a[@href='/web/index.php/directory/viewDirectory']")
maintenance_link_locator = (By.XPATH, "//a[@href='/web/index.php/maintenance/viewMaintenanceModule']")
claim_link_locator = (By.XPATH, "//a[@href='/web/index.php/claim/viewClaimModule']")
buzz_link_locator = (By.XPATH, "//a[@href='/web/index.php/buzz/viewBuzz']")





