from base.selenium_base import SeleniumBase
from ..locator import *
from data.orangeHRM_data import *
import time


class Login(SeleniumBase):
    def __init__(self, driver):
        super().__init__(driver)

    def enter_username(self, username):
        self.enter_values(username_locator, username)

    def enter_password(self, password):
        self.enter_values(password_locator, password)

    def submit_login(self):
        self.click_element(submit_login_locator)

    def verify_incorrect_login(self):
        invalid_login_txt = self.get_text(invalid_login_err_locator)
        try:
            if invalid_login_txt == 'Invalid credentials':
                print(f"Error, {invalid_login_txt}")
            else:
                print(f"Error found")
        except Exception as e:
            print(f"Error")
            raise

    def click_pim(self):
        self.click_element(pim_link_locator)

    def click_add_employee(self):
        self.click_element(add_new_employee_locator)

    def clear_firstname(self):
        self.clear_input(firstname_input_locator)

    def clear_middlename(self):
        self.clear_input(middlename_input_locator)

    def clear_lastname(self):
        self.clear_input(lastname_input_locator)

    def enter_firstname(self, firstname):
        self.enter_values(firstname_input_locator, firstname)

    def enter_middlename(self,middlename):
        self.enter_values(middlename_input_locator, middlename)

    def enter_lastname(self,lastname):
        self.enter_values(lastname_input_locator, lastname)

    def add_emplyoyee(self):
        self.click_element(add_employee_locator)

    def click_employee_list(self):
        self.click_element(employee_list_locator)
    def click_edit_employee(self):
        self.click_element(edit_employee_locator)

    def update_employee_btn(self):
        self.click_element(update_emp_personal_details_locator)

    def click_delete_employee(self):
        self.click_element(delete_employee_locator)

    def click_to_confirm_delete(self):
        self.click_element(delete_confirm_btn_locator)

    def click_to_admin(self):
        self.click_element(admin_link_locator)

    # def admin_navbar(self):
    #     elements = self.get_elements(admin_navbar_locator)
    #     print(elements)

    def verify_admin_navbar(self):
        user_mgnt_menu_text = self.get_text(user_mgnt_locator)
        assert user_mgnt_menu_text == orangehrm_test_data['adminpage']['nav1']

        job_menu_text = self.get_text(job_locator)
        assert job_menu_text == orangehrm_test_data['adminpage']['nav2']

        organization_menu_text = self.get_text(organization_locator)
        assert organization_menu_text == orangehrm_test_data['adminpage']['nav3']

        qualification_menu_text = self.get_text(qualification_locator)
        assert qualification_menu_text == orangehrm_test_data['adminpage']['nav4']

        # more_menu_text = self.get_text(more_locator)
        # assert more_menu_text == orangehrm_test_data['adminpage']['nav5']

    def verify_admin_main_menu(self):
        admin_menu_text = self.get_text(admin_link_locator)
        assert admin_menu_text == orangehrm_test_data['adminpage']['leftmenu']['admin']

        pim_menu_text = self.get_text(pim_link_locator)
        assert pim_menu_text == orangehrm_test_data['adminpage']['leftmenu']['pim']

        leave_menu_text = self.get_text(leave_link_locator)
        assert leave_menu_text == orangehrm_test_data['adminpage']['leftmenu']['leave']

        time_menu_text = self.get_text(time_link_locator)
        assert time_menu_text == orangehrm_test_data['adminpage']['leftmenu']['time']

        recruitment_menu_text = self.get_text(recruitment_link_locator)
        assert recruitment_menu_text == orangehrm_test_data['adminpage']['leftmenu']['recruitment']

        myinfo_menu_text = self.get_text(myinfo_link_locator)
        assert myinfo_menu_text == orangehrm_test_data['adminpage']['leftmenu']['myinfo']

        performance_menu_text = self.get_text(performance_link_locator)
        assert performance_menu_text == orangehrm_test_data['adminpage']['leftmenu']['performance']

        dashboard_menu_text = self.get_text(dashboard_link_locator)
        assert dashboard_menu_text == orangehrm_test_data['adminpage']['leftmenu']['dashboard']

        directory_menu_text = self.get_text(directory_link_locator)
        assert directory_menu_text == orangehrm_test_data['adminpage']['leftmenu']['directory']

        maintenance_menu_text = self.get_text(maintenance_link_locator)
        assert maintenance_menu_text == orangehrm_test_data['adminpage']['leftmenu']['maintenance']

        claim_menu_text = self.get_text(claim_link_locator)
        assert claim_menu_text == orangehrm_test_data['adminpage']['leftmenu']['claim']

        buzz_menu_text = self.get_text(buzz_link_locator)
        assert buzz_menu_text == orangehrm_test_data['adminpage']['leftmenu']['buzz']

    def click_forgot_password(self):
        self.click_element(forgot_password_locator)

# ------------------------------------ Function Start Here ------------------------------------------------#
    def forgot_password(self, username:str):
        self.click_forgot_password()
        self.enter_username(username)
        time.sleep(2)
        self.submit_login()
        time.sleep(4)

    def incorrect_login(self, username:str, incorrect_password:str):
        self.enter_username(username)
        time.sleep(2)
        self.enter_username(username)
        self.enter_password(incorrect_password)
        time.sleep(2)
        self.submit_login()
        time.sleep(2)
        self.verify_incorrect_login()
        time.sleep(3)

    def login_success(self, username:str, password:str):
        self.enter_username(username)
        self.enter_password(password)
        time.sleep(2)
        self.submit_login()
        time.sleep(3)
        # self.verify_login_success()

    def validate_admin_page(self):
        self.click_to_admin()
        page_title = self.driver.title
        assert page_title == orangehrm_test_data['adminpage']['page_title']
        self.verify_admin_navbar()

    def validate_admin_main_menu(self):
        self.click_to_admin()
        self.verify_admin_main_menu()

    def add_employee(self, firstname:str, middlename:str, lastname:str):
        self.click_pim()
        self.click_add_employee()
        self.enter_firstname(firstname)
        self.enter_middlename(middlename)
        self.enter_lastname(lastname)
        time.sleep(2)
        self.add_emplyoyee()
        time.sleep(2)

    def update_employee(self, firstname:str, middlename:str, lastname:str):
        self.click_employee_list()
        time.sleep(2)
        self.click_edit_employee()
        # self.clear_firstname()
        time.sleep(2)
        self.enter_firstname(firstname)
        # self.clear_middlename()
        time.sleep(2)
        self.enter_middlename(middlename)
        # self.clear_lastname()
        time.sleep(2)
        self.enter_lastname(lastname)
        time.sleep(2)
        self.update_employee_btn()
        time.sleep(2)

    def delete_employee(self):
        self.click_employee_list()
        self.click_delete_employee()
        time.sleep(2)
        self.click_to_confirm_delete()
        time.sleep(2)