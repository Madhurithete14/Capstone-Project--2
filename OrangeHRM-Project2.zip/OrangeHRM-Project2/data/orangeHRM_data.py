URL = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login"
BROWSER = 'chrome'
headless = False  # This will not launch if it True, it will execute in headless,

orangehrm_test_data = {
    "login":
        {
            "username": "Admin",
            "password": "admin123",
            "incorrect_password": "Invalid password",
            "login_failed_err_msg": "Invalid credentials",
        },
    "addnew":
        {
            "firstname": "madhuri",
            "middlename": "babasaheb",
            "lastname": "rahane"
        },
    "update":
        {
            "firstname": "MADHURI",
            "middlename": "BABASAHEB",
            "lastname": "RAHANE"
        },
    "adminpage":
        {
            "page_title": "OrangeHRM",
            "nav1": "User Management",
            "nav2": "Job",
            "nav3": "Organization",
            "nav4": "Qualifications",
            "nav5": "More",
            "leftmenu":
                {
                    "admin": "Admin",
                    "pim": "PIM",
                    "leave": "Leave",
                    "time": "Time",
                    "recruitment": "Recruitment",
                    "myinfo": "My Info",
                    "performance": "Performance",
                    "dashboard": "Dashboard",
                    "directory": "Directory",
                    "maintenance": "Maintenance",
                    "claim": "Claim",
                    "buzz": "Buzz"
                }

        }
}